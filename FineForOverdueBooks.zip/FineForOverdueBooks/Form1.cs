﻿using System;
using System.Windows.Forms;

namespace FineForOverdueBooks
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            // Read user input from text boxes
            int numberOfBooks = int.Parse(booksTextBox.Text);
            int overdueDays = int.Parse(daysTextBox.Text);

            // Calculate library fine and display the result
            double fine = CalculateFine(numberOfBooks, overdueDays);
            resultLabel.Text = $"Total fine: ${fine:F2}";
        }

        private double CalculateFine(int books, int days)
        {
            double fine = 0;

            for (int i = 1; i <= days; i++)
            {
                if (i <= 7)
                {
                    fine += 0.10 * books; // First 7 days
                }
                else
                {
                    fine += 0.20 * books; // Additional days
                }
            }

            return fine;
        }
    }
}
