﻿using System;
using System.Windows.Forms;

namespace DeliveryCharges
{
    public partial class DeliveryForm : Form
    {
        // Arrays to store zip codes and delivery charges
        private string[] zipCodes = { "12345", "23456", "34567", "45678", "56789", "67890", "78901", "89012", "90123", "01234" };
        private decimal[] deliveryCharges = { 5.99m, 6.49m, 7.99m, 8.99m, 9.49m, 10.99m, 12.99m, 14.99m, 15.99m, 18.99m };

        public DeliveryForm()
        {
            InitializeComponent();
        }

        private void checkButton_Click(object sender, EventArgs e)
        {
            string enteredZipCode = zipCodeTextBox.Text;

            // Check if zip code is in the array
            int index = Array.IndexOf(zipCodes, enteredZipCode);

            if (index >= 0)
            {
                // Display the delivery charge for the entered zip code
                resultLabel.Text = $"Delivery charge for {enteredZipCode} is ${deliveryCharges[index]:0.00}";
            }
            else
            {
                // Display message if zip code is not found
                resultLabel.Text = "Sorry, we do not deliver to this zip code.";
            }
        }
    }
}