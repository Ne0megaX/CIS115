﻿namespace Dinopedia
{
    partial class Dinopedia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dinopedia));
            this.btnTryannosaurus = new System.Windows.Forms.Button();
            this.btnQuetzalcoatlus = new System.Windows.Forms.Button();
            this.btnNyasasaurus = new System.Windows.Forms.Button();
            this.btnTriceratops = new System.Windows.Forms.Button();
            this.btnAnklosaurus = new System.Windows.Forms.Button();
            this.btnMicroraptor = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnTryannosaurus
            // 
            this.btnTryannosaurus.BackColor = System.Drawing.Color.GreenYellow;
            this.btnTryannosaurus.Location = new System.Drawing.Point(68, 212);
            this.btnTryannosaurus.Name = "btnTryannosaurus";
            this.btnTryannosaurus.Size = new System.Drawing.Size(98, 23);
            this.btnTryannosaurus.TabIndex = 0;
            this.btnTryannosaurus.Text = "Tryannosaurus";
            this.btnTryannosaurus.UseVisualStyleBackColor = false;
            this.btnTryannosaurus.Click += new System.EventHandler(this.btnTyrannosaurus_Click);
            // 
            // btnQuetzalcoatlus
            // 
            this.btnQuetzalcoatlus.BackColor = System.Drawing.Color.GreenYellow;
            this.btnQuetzalcoatlus.Location = new System.Drawing.Point(214, 212);
            this.btnQuetzalcoatlus.Name = "btnQuetzalcoatlus";
            this.btnQuetzalcoatlus.Size = new System.Drawing.Size(86, 23);
            this.btnQuetzalcoatlus.TabIndex = 1;
            this.btnQuetzalcoatlus.Text = "Quetzalcoatlus";
            this.btnQuetzalcoatlus.UseVisualStyleBackColor = false;
            this.btnQuetzalcoatlus.Click += new System.EventHandler(this.btnQuetzalcoatlus_Click);
            // 
            // btnNyasasaurus
            // 
            this.btnNyasasaurus.BackColor = System.Drawing.Color.GreenYellow;
            this.btnNyasasaurus.Location = new System.Drawing.Point(341, 212);
            this.btnNyasasaurus.Name = "btnNyasasaurus";
            this.btnNyasasaurus.Size = new System.Drawing.Size(86, 23);
            this.btnNyasasaurus.TabIndex = 2;
            this.btnNyasasaurus.Text = "Nyasasaurus";
            this.btnNyasasaurus.UseVisualStyleBackColor = false;
            this.btnNyasasaurus.Click += new System.EventHandler(this.btnNyasasaurus_Click);
            // 
            // btnTriceratops
            // 
            this.btnTriceratops.BackColor = System.Drawing.Color.GreenYellow;
            this.btnTriceratops.Location = new System.Drawing.Point(79, 290);
            this.btnTriceratops.Name = "btnTriceratops";
            this.btnTriceratops.Size = new System.Drawing.Size(75, 23);
            this.btnTriceratops.TabIndex = 3;
            this.btnTriceratops.Text = "Triceratops";
            this.btnTriceratops.UseVisualStyleBackColor = false;
            this.btnTriceratops.Click += new System.EventHandler(this.btnTriceratops_Click);
            // 
            // btnAnklosaurus
            // 
            this.btnAnklosaurus.BackColor = System.Drawing.Color.GreenYellow;
            this.btnAnklosaurus.Location = new System.Drawing.Point(214, 290);
            this.btnAnklosaurus.Name = "btnAnklosaurus";
            this.btnAnklosaurus.Size = new System.Drawing.Size(97, 23);
            this.btnAnklosaurus.TabIndex = 4;
            this.btnAnklosaurus.Text = "Ankylosaurus";
            this.btnAnklosaurus.UseVisualStyleBackColor = false;
            this.btnAnklosaurus.Click += new System.EventHandler(this.btnAnklosaurus_Click);
            // 
            // btnMicroraptor
            // 
            this.btnMicroraptor.BackColor = System.Drawing.Color.GreenYellow;
            this.btnMicroraptor.Location = new System.Drawing.Point(352, 290);
            this.btnMicroraptor.Name = "btnMicroraptor";
            this.btnMicroraptor.Size = new System.Drawing.Size(75, 23);
            this.btnMicroraptor.TabIndex = 5;
            this.btnMicroraptor.Text = "Microraptor";
            this.btnMicroraptor.UseVisualStyleBackColor = false;
            this.btnMicroraptor.Click += new System.EventHandler(this.btnMicroraptor_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(128, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(266, 50);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Dinopedia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(505, 481);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnMicroraptor);
            this.Controls.Add(this.btnAnklosaurus);
            this.Controls.Add(this.btnTriceratops);
            this.Controls.Add(this.btnNyasasaurus);
            this.Controls.Add(this.btnQuetzalcoatlus);
            this.Controls.Add(this.btnTryannosaurus);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Dinopedia";
            this.Text = "Dinopedia";
            this.Load += new System.EventHandler(this.Dinopedia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnTryannosaurus;
        private System.Windows.Forms.Button btnQuetzalcoatlus;
        private System.Windows.Forms.Button btnNyasasaurus;
        private System.Windows.Forms.Button btnTriceratops;
        private System.Windows.Forms.Button btnAnklosaurus;
        private System.Windows.Forms.Button btnMicroraptor;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}