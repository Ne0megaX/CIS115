﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dinopedia
{
    public partial class Dinopedia : Form
    {
        public Dinopedia()
        {
            InitializeComponent();
        }

        private void btnTyrannosaurus_Click(object sender, EventArgs e)
        {
            new TyrannosaurusForm().Show();
            this.Hide();
        }
      



        private void btnQuetzalcoatlus_Click(object sender, EventArgs e)
        {
            new QuetzalcoatlusForm().Show();
            this.Hide();
        }
        

        private void Dinopedia_Load(object sender, EventArgs e)
        {

        }

        private void btnNyasasaurus_Click(object sender, EventArgs e)
        {
            new NyasasaurusForm().Show();
            this.Hide();
        }

        private void btnTriceratops_Click(object sender, EventArgs e)
        {
            new TriceratopsForm().Show();
            this.Hide();
        }

        private void btnAnklosaurus_Click(object sender, EventArgs e)
        {
            new AnkylosaurusForm().Show();
            this.Hide();
        }

        private void btnMicroraptor_Click(object sender, EventArgs e)
        {
            new MicroraptorForm().Show();
            this.Hide();
        }
    }
}

