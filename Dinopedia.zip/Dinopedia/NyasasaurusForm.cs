﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dinopedia
{
    public partial class NyasasaurusForm : Form
    {
        public NyasasaurusForm()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            new Dinopedia().Show();
            this.Hide();
        }
    }
}
