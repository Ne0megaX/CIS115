﻿using System;
using System.Windows.Forms;

namespace PaintingEstimate
{
    public partial class PaintingForm : Form
    {
        public PaintingForm()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtLength.Text, out double length) && double.TryParse(txtWidth.Text, out double width))
            {
                double cost = CalculatePaintingCost(length, width);
                lblResult.Text = $"Estimated Cost: ${cost:F2}";
            }
            else
            {
                MessageBox.Show("Please enter valid numeric values.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private double CalculatePaintingCost(double length, double width)
        {
            const double pricePerSqFt = 6.0;
            double wallHeight = 9.0;

            double totalArea = (2 * (length * wallHeight)) + (2 * (width * wallHeight)); // Four walls
            return totalArea * pricePerSqFt;
        }
    }
}
