﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace TestScoreListApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // Collect test scores from textboxes into an array
                int[] scores = {
                    int.Parse(txtScore1.Text),
                    int.Parse(txtScore2.Text),
                    int.Parse(txtScore3.Text),
                    int.Parse(txtScore4.Text),
                    int.Parse(txtScore5.Text),
                    int.Parse(txtScore6.Text),
                    int.Parse(txtScore7.Text),
                    int.Parse(txtScore8.Text)
                };

                // Validate scores
                if (scores.Any(score => score < 0 || score > 100))
                {
                    MessageBox.Show("Scores must be between 0 and 100.");
                    return;
                }

                // Calculate average
                double average = scores.Average();

                // Display results in the list box
                lstResults.Items.Clear();
                lstResults.Items.Add($"Average Score: {average:F2}");

                for (int i = 0; i < scores.Length; i++)
                {
                    double difference = scores[i] - average;
                    lstResults.Items.Add($"Score {i + 1}: {scores[i]} (Difference: {difference:+0.00;-0.00})");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid numeric values for all scores.");
            }
        }
    }
}